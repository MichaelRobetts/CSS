# Image Gallery Project

Image Gallery mini-project from my Tailwind course.

![Alt text](images/image-gallery.png)
