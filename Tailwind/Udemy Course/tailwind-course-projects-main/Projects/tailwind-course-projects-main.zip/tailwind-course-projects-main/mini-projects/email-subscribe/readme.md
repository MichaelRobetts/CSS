# Email Subscribe Project

Email Subscribe mini-project from my Tailwind course.

![Alt text](images/email-subscribe.png)
