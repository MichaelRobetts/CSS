# Login Modal Project

Login Modal mini-project from my Tailwind course.

![Alt text](images/login-modal.png)
