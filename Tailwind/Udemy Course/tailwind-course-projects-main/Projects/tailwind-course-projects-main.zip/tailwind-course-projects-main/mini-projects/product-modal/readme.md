# Product Modal Project

Product Modal mini-project from my Tailwind course.

![Alt text](images/product-modal.png)
