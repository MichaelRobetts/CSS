# Bookmark Website

Bookmark landing page from my Tailwind course and from [Frontend Mentor Challenge](https://www.frontendmentor.io/challenges/bookmark-landing-page-5d0b588a9edda32581d29158)

## Usage

Install dependencies

```
npm Install
```

Run Tailwind CLI

```
npm run watch
```

![Alt text](images/bookmark.png)
